package ImageHoster.service;

import ImageHoster.model.User;
import ImageHoster.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.regex.*;

@Service
public class UserService {

  @Autowired
  private UserRepository userRepository;



  //here the method Call the registerUser() method in the UserRepository class to persist the user record in the database
  public void registerUser(User newUser) {
    userRepository.registerUser(newUser);
  }

  //if we did not have any user in the database,so the user with username 'upgrad' and password 'password' was hard-coded
  //here This method returned true if the username was 'upgrad' and password is 'password'
  //here now let us change the implementation of this method
  //This method get the User type object
  //here the method Calls the checkUser() method in the Repository passing the username and password which checks the username and password in the database
  //here The Repository returns User type object if user with entered username and password exists in the database
  //Else if nothing found returns null
  public User login(User user) {
    User existingUser = userRepository.checkUser(user.getUsername(), user.getPassword());
    if (existingUser != null) {
      return existingUser;
    } else {
      return null;
    }
  }

}
